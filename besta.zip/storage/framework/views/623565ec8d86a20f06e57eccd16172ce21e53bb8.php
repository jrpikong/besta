<div class="slider-container light rev_slider_wrapper" style="height: 700px;">
    <div id="revolutionSlider" class="slider rev_slider" data-plugin-revolution-slider data-plugin-options="{'delay': 9000, 'gridwidth': 1170, 'gridheight': 700, 'disableProgressBar': 'on'}">
        <ul>
            <?php if($sliders): ?>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-transition="fade">
                        <img src="<?php echo e(Voyager::image($slider->image)); ?>"
                             alt=""
                             data-bgposition="center 100%"
                             data-bgfit="cover"
                             data-bgrepeat="no-repeat"
                             class="rev-slidebg">

                        <div class="tp-caption top-label tp-caption-custom-stripe"
                             data-x="right" data-hoffset="100"
                             data-y="bottom" data-voffset="101"
                             data-start="1000"
                             data-transform_in="x:[100%];opacity:0;s:1000;"># <?php echo e($slider->title); ?></div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
</div>