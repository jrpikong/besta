<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>besta.id</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Porto - Responsive HTML5 Template">
    <meta name="author" content="okler.net">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico" type="image/x-icon')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('img/apple-touch-icon.png')); ?>">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

    <!-- Web Fonts  -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/animate/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/simple-line-icons/css/simple-line-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/owl.carousel/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/owl.carousel/assets/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/magnific-popup/magnific-popup.min.css')); ?>">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/theme-elements.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/theme-blog.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/theme-shop.css')); ?>">

    <!-- Current Page CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/rs-plugin/css/settings.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/rs-plugin/css/layers.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/rs-plugin/css/navigation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/nivo-slider/nivo-slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/nivo-slider/default/default.css')); ?>">

    <!-- Demo CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/demos/demo-construction.css')); ?>">

    <!-- Skin CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/skins/skin-construction.css')); ?>">

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

    <!-- Head Libs -->
    <script src="<?php echo e(asset('vendor/modernizr/modernizr.min.js')); ?>"></script>

</head>

<body data-spy="scroll" data-target="#sidebar" data-offset="120">
<div class="body">
    
    <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div role="main" class="main">
        <?php echo $__env->yieldContent("content"); ?>
    </div>

    
    <?php echo $__env->make("partials.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
</div>



<!-- Vendor -->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.appear/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-cookie/jquery-cookie.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/popper/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/common/common.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.validation/jquery.validation.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.gmap/jquery.gmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.lazyload/jquery.lazyload.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/isotope/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/vide/vide.min.js')); ?>"></script>

<!-- Theme Base, Components and Settings -->
<script src="<?php echo e(asset('js/theme.js')); ?>"></script>

<!-- Current Page Vendor and Views -->
<script src="<?php echo e(asset('vendor/rs-plugin/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>"></script>

<!-- Current Page Vendor and Views -->
<script src="<?php echo e(asset('vendor/nivo-slider/jquery.nivo.slider.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/views/view.contact.js')); ?>"></script>

<!-- Demo -->
<script src="<?php echo e(asset('js/demos/demo-construction.js')); ?>"></script>

<!-- Theme Custom -->
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<!-- Theme Initialization Files -->
<script src="<?php echo e(asset('js/theme.init.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>